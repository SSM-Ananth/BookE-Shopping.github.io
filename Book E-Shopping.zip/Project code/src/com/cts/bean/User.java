package com.cts.bean;

public class User {
	private String first_Name;
	private String last_Name;
	private int age;
	private String gender;
	private Long contactNumer;
	private String emailId;
	private String password;
	public User(String first_Name, String last_Name, int age, String gender, Long contactNumer, String emailId,
			String password) {
		super();
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.age = age;
		this.gender = gender;
		this.contactNumer = contactNumer;
		this.emailId = emailId;
		this.password = password;
	}

	public String getFirst_Name() {
		return first_Name;
	}
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}
	public String getLast_Name() {
		return last_Name;
	}
	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Long getContactNumer() {
		return contactNumer;
	}
	public void setContactNumer(Long contactNumer) {
		this.contactNumer = contactNumer;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
