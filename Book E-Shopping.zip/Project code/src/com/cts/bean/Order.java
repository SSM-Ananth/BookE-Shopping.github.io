package com.cts.bean;

public class Order {
private int orderId;
private int userId;
private String address;
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

}
