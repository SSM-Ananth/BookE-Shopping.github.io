package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bean.Order;
import com.cts.dao.OrderDAO;


@WebServlet("/Result")
public class Result extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Result() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		OrderDAO od=new OrderDAO();
		String address=request.getParameter("address")+","+request.getParameter("city")+","+request.getParameter("state")+","+request.getParameter("zip");
		int userId=Integer.parseInt(request.getParameter("userId"));
		Order order=new Order();
		order.setAddress(address);
		order.setUserId(userId);
		int status=0;
		status=od.insert(order);
		if(status!=0) {
			response.sendRedirect("paymentResult.jsp");
		}else {
			out.println("<h1>Error While Placing the Order.........</h1>");
		}
		
		
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
