package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bean.User;
import com.cts.dao.UserDAO;

/**
 * Servlet implementation class EmailServlet
 */
@WebServlet("/EmailServlet")
public class EmailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EmailServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		try {
			String fName = request.getParameter("First_Name");
			String lName = request.getParameter("Last_Name");
			int age = Integer.parseInt(request.getParameter("Age"));
			String gender = request.getParameter("Gender");
			long contactNumber = Long.parseLong(request.getParameter("Contact_Number"));
			String email = request.getParameter("Email_Id");
			String password = request.getParameter("Password");
			User user = new User(fName, lName, age, gender, contactNumber, email, password);
			UserDAO userDAO = new UserDAO();

			int checkStatus = 0;
			checkStatus = userDAO.validEmail(user.getEmailId());
			if (checkStatus == 0) {
				request.setAttribute("user", user);

				RequestDispatcher rd = request.getRequestDispatcher("InsertData");
				rd.forward(request, response);

			} else
			{
				response.sendRedirect("UnRegister.jsp");
			
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
