package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bean.Cart;
import com.cts.dao.BookDAO;
import com.cts.dao.CartDAO;


@WebServlet("/UpdateCart")
public class UpdateCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{PrintWriter out=response.getWriter();
		CartDAO cd=new CartDAO();
		BookDAO bd=new BookDAO();
		Cart cart=new Cart();
		
		cart.setUserId(Integer.parseInt(request.getParameter("userId")));
		cart.setBook(bd.readByName(request.getParameter("bookName")).get(0));
		cart.setQuantity(Integer.parseInt(request.getParameter("quantity")));
		int status=cd.update(cart);
		if(status!=0) {
			request.setAttribute("userId",cart.getUserId());
			RequestDispatcher rd=request.getRequestDispatcher("ViewCart");
			rd.forward(request, response);
		}else {
			out.println("Error while updating Cart.........");
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
