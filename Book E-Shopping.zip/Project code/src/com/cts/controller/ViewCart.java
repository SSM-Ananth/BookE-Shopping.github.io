package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bean.Book;
import com.cts.bean.Cart;
import com.cts.dao.BookDAO;
import com.cts.dao.CartDAO;


@WebServlet("/ViewCart")
public class ViewCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ViewCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		CartDAO cd=new CartDAO();
		int user=Integer.parseInt(request.getParameter("userId"));
		
		List<Cart> cartList= cd.read(user);
		if(!cartList.isEmpty()) {		
		request.setAttribute("cartList", cartList);
		
		RequestDispatcher rd=request.getRequestDispatcher("ViewCart.jsp");
		rd.forward(request,response);
		}
		else {
			response.sendRedirect("NoCart.jsp");
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
