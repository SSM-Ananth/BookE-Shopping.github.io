
package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;

import com.cts.bean.User;
import com.cts.dao.UserDAO;

/**
 * Servlet implementation class InsertData
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		try {
			UserDAO userDAO = new UserDAO();
			String emailId = request.getParameter("Email_Id");
			String password = request.getParameter("Password");

			int checkStatus = 0, userId = 0;

			checkStatus = userDAO.validUser(emailId, password);
			userId = userDAO.getUserId(emailId, password);
			
			if (checkStatus == 1) {
				HttpSession session=request.getSession();
				session.setAttribute("userId",userId);

				RequestDispatcher rd=request.getRequestDispatcher("HomePage");
				rd.forward(request, response);

			} else {
				response.sendRedirect("UserDoesntExist.html");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
