package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.bean.Book;

public class BookDAO {
	private Connection con = null;
	private ResultSet rs = null;
	private Statement st = null;
	private PreparedStatement ps = null;

	public List<Book> readAll() {
		List<Book> bookList = new ArrayList<Book>();
		try {
			con = connect();
			st = con.createStatement();
			rs = st.executeQuery("select * from bookInventory");
			while (rs.next()) {
				Book book = new Book();
				book.setBookId(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setImage(rs.getString(3));
				book.setPrice(rs.getFloat(4));
				book.setQuantity_In_Stock(rs.getInt(5));
				book.setBinding(rs.getString(6));
				book.setLanguage(rs.getString(7));
				book.setAuthor(rs.getString(8));
				book.setPublisher(rs.getString(9));
				bookList.add(book);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return bookList;

	}

	public List<Book> readByName(String bookName) {
		List<Book> b = new ArrayList<Book>();

		try {
			con = connect();
			st = con.createStatement();
			rs = st.executeQuery(
					"select * from bookInventory where book_Name like '%" + bookName + "%' group by book_Id");
			while (rs.next()) {
				Book book = new Book();
				book.setBookId(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setImage(rs.getString(3));
				book.setPrice(rs.getFloat(4));
				book.setQuantity_In_Stock(rs.getInt(5));
				book.setBinding(rs.getString(6));
				book.setLanguage(rs.getString(7));
				book.setAuthor(rs.getString(8));
				book.setPublisher(rs.getString(9));
				b.add(book);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return b;

	}

	public Book readById(String bookId) {
		Book book = new Book();
		try {
			con = connect();
			ps = con.prepareStatement("select * from bookInventory where Book_Id=?");
			ps.setString(1, bookId);
			rs = ps.executeQuery();
			if (rs.next()) {

				book.setBookId(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setImage(rs.getString(3));
				book.setPrice(rs.getFloat(4));
				book.setQuantity_In_Stock(rs.getInt(5));
				book.setBinding(rs.getString(6));
				book.setLanguage(rs.getString(7));
				book.setAuthor(rs.getString(8));
				book.setPublisher(rs.getString(9));

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return book;

	}

	public void updateQuantity(Integer newQuantity, String bookId) {
		try {
			con = connect();

			ps = con.prepareStatement("update Bookinventory set Quantity_in_stock=? where Book_id=?");
			ps.setInt(1, newQuantity);
			ps.setString(2, bookId);
			int status = ps.executeUpdate();
			if (status != 0) {
				System.out.println("Successfully updated");
			} else {
				System.out.println("Error while updating......");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Book_E_Shopping", "root", "root");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException s) {
			s.printStackTrace();
		}
		return con;

	}

}
