package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cts.bean.User;

public class UserDAO {
	private static Connection conn = null;
	private PreparedStatement pstmt = null;

	public int insert(User u) throws Exception {
		UserDAO.connect();
		pstmt = conn.prepareStatement(
				"insert into user (First_Name,Last_Name,Age,Gender,Contact_Number,Email_Id,Password) values (?,?,?,?,?,?,?)");
		int insertStatus = 0;
		pstmt.setString(1, u.getFirst_Name());
		pstmt.setString(2, u.getLast_Name());
		pstmt.setInt(3, u.getAge());
		pstmt.setString(4, u.getGender());
		pstmt.setLong(5, u.getContactNumer());
		pstmt.setString(6, u.getEmailId());
		pstmt.setString(7, u.getPassword());

		insertStatus = pstmt.executeUpdate();
		return insertStatus;
	}

	public int validUser(String id, String password) {

	 

		int count = 0;

		try {
			UserDAO.connect();
			String sql = "Select * from user where Email_Id=? and Password=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				count = 1;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	public int getUserId(String id, String password) {
		
		
		int userId = 0;

		try {
			UserDAO.connect();
			String sql = "Select user_Id from user where Email_Id=? and Password=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				userId=rs.getInt(1);
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userId;
		
	}
	
	
	public int validEmail(String email)
	{
		int count=0;
		try {
			UserDAO.connect();
			String sql="select * from user where Email_Id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, email);
			System.out.println(email);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				count = 1;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return count;
	}

	public static Connection connect() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/book_e_shopping", "root", "root");
		return conn;
	}

}
