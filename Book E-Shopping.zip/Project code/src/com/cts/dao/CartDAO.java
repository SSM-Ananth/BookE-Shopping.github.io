package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.bean.Cart;

public class CartDAO {
	private Connection con = null;
	private ResultSet rs = null;
	private Statement st = null;
	private PreparedStatement ps = null;

	public int insert(Cart cart) {
		int status = 0;
		try {
			con = connect();
			String sql = "insert into cart values (?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setInt(1, cart.getUserId());
			ps.setString(2, cart.getBook().getBookId());
			ps.setInt(3, cart.getQuantity());
			status = ps.executeUpdate();
			if (status != 0) {
				System.out.println("Inserted successfully....");
			} else {
				System.out.println("Error while inserting cart....");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public List<Cart> read(Integer userId) {
		List<Cart> cartList = new ArrayList<Cart>();
		BookDAO bd = new BookDAO();
		try {

			con = connect();
			String sql = "select * from cart where user_id=" + userId;
			st = con.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				Cart cart = new Cart();
				cart.setUserId(rs.getInt(1));
				cart.setBook(bd.readById(rs.getString(2)));
				cart.setQuantity(rs.getInt(3));
				cartList.add(cart);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cartList;

	}

	public Cart readForEdit(Integer userId, String bookId) {
		BookDAO bd = new BookDAO();
		Cart cart = new Cart();
		try {
			con = connect();
			String sql = "Select * from Cart where user_id=? and book_id=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, userId);
			ps.setString(2, bookId);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				cart.setUserId(rs.getInt(1));
				cart.setBook(bd.readById(rs.getString(2)));
				cart.setQuantity(rs.getInt(3));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return cart;

	}

	public int update(Cart cart) {
		int status = 0;
		try {
			con = connect();
			String sql = "update Cart set Quantity=? where user_id=? and Book_Id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, cart.getQuantity());
			ps.setInt(2, cart.getUserId());
			ps.setString(3, cart.getBook().getBookId());
			status = ps.executeUpdate();
			if (status != 0) {
				System.out.println("Updated successfully....");
			} else {
				System.out.println("Error while updating cart....");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public int delete(String bookId, Integer userId) {
		int status = 0;
		try {
			con = connect();
			String sql = "delete from Cart where user_id=? and Book_Id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, userId);
			ps.setString(2, bookId);
			status = ps.executeUpdate();
			if (status != 0) {
				System.out.println("Updated successfully....");
			} else {
				System.out.println("Error while updating cart....");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Book_E_Shopping", "root", "root");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException s) {
			s.printStackTrace();
		}
		return con;

	}

}
