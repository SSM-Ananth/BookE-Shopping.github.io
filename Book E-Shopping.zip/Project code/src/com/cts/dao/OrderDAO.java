package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.bean.Order;

public class OrderDAO {
	private static Connection conn = null;
	private ResultSet rs = null;
	private Statement stmt = null;
	private PreparedStatement pstmt = null;

	public int insert(Order order) {
		int status = 0;
		try {
			conn = connect();
			String sql = "insert into order_details(user_id,address_to_ship) values (?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, order.getUserId());
			ps.setString(2, order.getAddress());
			status = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return status;

	}

	public List<Order> readAll(Integer userId) throws Exception {
		List<Order> od = new ArrayList<Order>();
		try {
			OrderDAO.connect();
			pstmt = conn.prepareStatement("select * from order_details where user_Id=?");
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Order o = new Order();
				o.setOrderId(rs.getInt(1));
				o.setUserId(rs.getInt(2));
				o.setAddress(rs.getString(3));
				od.add(o);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return od;
	}

	public int delete(int id) throws Exception {
		int deleteStatus = 0;
		try {
			OrderDAO.connect();
			pstmt = conn.prepareStatement("delete from order_details where order_Id=?");
			pstmt.setInt(1, id);
			deleteStatus = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				conn.close();
		}

		return deleteStatus;
	}

	public static Connection connect() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/book_e_shopping", "root", "root");
		return conn;
	}
}